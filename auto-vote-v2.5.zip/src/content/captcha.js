window.dontSolve = false
window.solvedCaptcha = false
chrome.runtime.onMessage.addListener(function(request/*, sender, sendResponse*/) {
    if (request.sendProject) {
        if (!window.loadedCaptcha) {
            window.loadedCaptcha = true
            if (request.settings.disabledClickCaptcha) {
                window.dontSolve = true
            }
            run()
        // In case captcha was solved before the page finished loading
        } else if (window.solvedCaptcha) {
            chrome.runtime.sendMessage({captchaPassed: 'double'})
        }
    }
})

function run() {
    if (window.portAlert) {
        window.portAlert.addEventListener('state', event => {
            chrome.runtime.sendMessage({message: event.detail.message, ignoreReport: true})
        })
    }

    if (window.location.href.match(/https?:\/\/(.+?\.)?google.com\/recaptcha\/api\d\/anchor/) || window.location.href.match(/https?:\/\/(.+?\.)?recaptcha.net\/recaptcha\/api\d\/anchor/) || window.location.href.match(/https?:\/\/(.+?\.)?google.com\/recaptcha\/enterprise\/anchor*/) || window.location.href.match(/https?:\/\/(.+?\.)?recaptcha.net\/recaptcha\/enterprise\/anchor*/)) {
        const timer1 = setInterval(()=>{
            // noinspection CssInvalidHtmlTagReference
            if (window.dontSolve || document.querySelector('head > captcha-widgets')) {
                clearInterval(timer1)
                return
            }

            if (document.querySelector('#recaptcha-anchor > div.recaptcha-checkbox-border') != null
                && isScrolledIntoView(document.querySelector('#recaptcha-anchor > div.recaptcha-checkbox-border'))
                && document.querySelector('#recaptcha-anchor > div.recaptcha-checkbox-border').style.display !== 'none') {
                // If there is an error in the captcha, do not proceed
                if (document.querySelector('.rc-anchor-error-msg-container').style.display !== 'none' && document.querySelector('.rc-anchor-error-msg-container').textContent.length > 0) return
                document.querySelector('#recaptcha-anchor > div.recaptcha-checkbox-border').click()
                clearInterval(timer1)
            }
        }, 1000)

        // Check if ReCaptcha challenge has passed
        const timer2 = setInterval(()=>{
            // If captcha passed
            if (document.getElementsByClassName('recaptcha-checkbox-checked').length >= 1 || (document.getElementById('g-recaptcha-response') != null && document.getElementById('g-recaptcha-response').value.length > 0)) {
                clearInterval(timer2)
                window.solvedCaptcha = true
                chrome.runtime.sendMessage({captchaPassed: true})
            }

            if (document.querySelector('.rc-anchor-error-msg-container').style.display !== 'none' && document.querySelector('.rc-anchor-error-msg-container').textContent.length > 0) {
                const text = document.querySelector('.rc-anchor-error-msg-container').textContent
                if (text.includes('Try reloading the page')) {
                    document.location.reload()
                } else {
                    // https://i.imgur.com/WJ3ce9s.png
                    if (!text.includes('Verification challenge expired') && !text.includes('Verification expired') && !text.includes('La validation a expiré') && !text.includes('Platnost výzvy ověření vypršela') && !text.includes('verificación caducó')) {
                        chrome.runtime.sendMessage({errorCaptcha: document.querySelector('.rc-anchor-error-msg-container').textContent})
                        clearInterval(timer2)
                    }
                }
            }
        }, 1000)
    } else if ((window.location.href.match(/https?:\/\/(.+?\.)?google.com\/recaptcha\/api\d\/bframe/) || window.location.href.match(/https?:\/\/(.+?\.)?recaptcha.net\/recaptcha\/api\d\/bframe/) || window.location.href.match(/https?:\/\/(.+?\.)?google.com\/recaptcha\/enterprise\/bframe*/) || window.location.href.match(/https?:\/\/(.+?\.)?recaptcha.net\/recaptcha\/enterprise\/bframe*/)) && document.querySelector('head > yandex-captcha-solver') == null) {
        // Integration with Buster: Captcha Solver for Humans
        let count = 0
        let repeat = 2
        const timer7 = setInterval(() => {

            if (document.getElementById('solver-button') != null && !document.getElementById('solver-button').className.includes('working') && !document.getElementById('recaptcha-verify-button').disabled) {
                if (document.querySelector('.rc-audiochallenge-error-message') != null && document.querySelector('.rc-audiochallenge-error-message').style.display !== 'none' && document.querySelector('.rc-audiochallenge-error-message').textContent > 0) {
                    repeat = 3
                }
                if (count >= repeat) {
                    chrome.runtime.sendMessage({reloadCaptcha: true})
                    clearInterval(timer7)
                    return
                }
                document.getElementById('solver-button').click()
                count++
            }

            if (document.querySelector('.rc-doscaptcha-body-text') != null && document.querySelector('.rc-doscaptcha-body-text').style.display !== 'none') {
                // https://i.imgur.com/q5BroJ7.png
                chrome.runtime.sendMessage({errorCaptcha: document.querySelector('.rc-doscaptcha-body-text').textContent})
                clearInterval(timer7)
            }

            // Click Verify button for NopeCHA extension using Speech solver
            if (document.querySelector("#audio-response")?.value.length > 3) {
                clearInterval(timer7)
                document.querySelector("#recaptcha-verify-button")?.click()
            }
        }, 2000)

        const timer3 = setInterval(() => {
            // If manual captcha completion is required
            if (document.getElementById("solver-button") == null && document.getElementById("rc-imageselect") != null && isScrolledIntoView(document.getElementById("rc-imageselect"))) {
                chrome.runtime.sendMessage({captcha: true})
                clearInterval(timer3)
            }
        }, 1000)
    } else if (window.location.href.match(/https?:\/\/(.+?\.)?google.com\/recaptcha\/api\/fallback*/) || window.location.href.match(/https?:\/\/(.+?\.)?recaptcha.net\/recaptcha\/api\/fallback*/) || window.location.href.match(/https?:\/\/(.+?\.)?google.com\/recaptcha\/enterprise\/fallback*/) || window.location.href.match(/https?:\/\/(.+?\.)?recaptcha.net\/recaptcha\/enterprise\/fallback*/)) {
        chrome.runtime.sendMessage({errorCaptcha: document.body.innerText.trim(), restartVote: true})
    } else if (window.location.href.match(/.hcaptcha.com\/captcha.v\d\//)) {
        const timer4 = setInterval(()=>{
            // noinspection CssInvalidHtmlTagReference
            if (window.dontSolve || document.querySelector('head > captcha-widgets')) {
                clearInterval(timer4)
                return
            }

            if (document.getElementById('checkbox') != null
                && isScrolledIntoView(document.getElementById('checkbox'))
                && document.getElementById('checkbox').style.display !== 'none') {
                document.getElementById('checkbox').click()
                clearInterval(timer4)
            }
        }, 1000)

        // Check if hCaptcha challenge has passed
        const timer5 = setInterval(()=>{
            if (document.getElementById('checkbox') != null && document.getElementById('checkbox').getAttribute('aria-checked') === 'true') {
                clearInterval(timer5)
                window.solvedCaptcha = true
                chrome.runtime.sendMessage({captchaPassed: true})
            }
        }, 1000)

        // If manual captcha completion is required
        const timer6 = setInterval(()=>{
            if (document.querySelector('body[class="no-selection"]') != null && document.querySelector('body[class="no-selection"]').getAttribute('aria-hidden') == null && document.querySelector('body[class="no-selection"]').style.display === '' && document.querySelector('head > yandex-captcha-solver') == null) {
                clearInterval(timer6)
                chrome.runtime.sendMessage({captcha: true})
            } else if (document.querySelector('head > yandex-captcha-solver') != null && document.querySelector('div[style="text-align: right; color: rgb(218, 94, 94);"]') != null) {
                chrome.runtime.sendMessage({errorCaptcha: document.querySelector('div[style="text-align: right; color: rgb(218, 94, 94);"]').textContent})
                clearInterval(timer5)
            }
        }, 1000)

        // If error in captcha https://i.imgur.com/EqEJoMr.png
        const timer9 = setInterval(() => {
            const status = document.querySelector('#status')
            if (status && status.style.display !== 'none' && status.innerText.length > 3) {
                chrome.runtime.sendMessage({errorCaptcha: status.innerText})
                clearInterval(timer9)
            }
        }, 1000)
    } else if (window.location.href.match(/https:\/\/challenges.cloudflare.com\/*/)) {
        const findTurnstileElement = (selector) => {
            let el = document.querySelector(selector)
            if (el) return el
            let root = null
            try {
                if (chrome.dom && chrome.dom.openOrClosedShadowRoot) {
                    root = chrome.dom.openOrClosedShadowRoot(document.body)
                }
            } catch (e) {}
            if (root) {
                el = root.querySelector(selector)
                if (el) return el
            }
            for (const elem of document.querySelectorAll('*')) {
                let sr = null
                try {
                    sr = (chrome.dom && chrome.dom.openOrClosedShadowRoot) ? chrome.dom.openOrClosedShadowRoot(elem) : elem.shadowRoot
                } catch (e) {}
                if (sr) {
                    el = sr.querySelector(selector)
                    if (el) return el
                }
            }
            return null
        }

        // Auto click Cloudflare Turnstile checkbox
        const timer7 = setInterval(() => {
            const btn = findTurnstileElement('input[type="checkbox"]') ||
                        findTurnstileElement('#cf-norobot-container span.mark') ||
                        findTurnstileElement('#challenge-stage span.mark') ||
                        findTurnstileElement('.ctp-checkbox-label') ||
                        findTurnstileElement('#challenge-stage')
            if (btn) {
                clearInterval(timer7)
                btn.click()
            }
        }, 1000)

        // Check if Cloudflare Turnstile challenge has passed
        const timer8 = setInterval(() => {
            const success = findTurnstileElement('#success') ||
                            findTurnstileElement('[data-state="success"]') ||
                            findTurnstileElement('.ctp-success') ||
                            findTurnstileElement('#success-text')
            if (success && success.style.display !== 'none') {
                clearInterval(timer8)
                window.solvedCaptcha = true
                chrome.runtime.sendMessage({captchaPassed: true})
            }
        }, 1000)
    }
}

function isScrolledIntoView(el) {
    const rect = el.getBoundingClientRect()
    const elemTop = rect.top
    const elemBottom = rect.bottom

    // Only completely visible elements return true:
    let isVisible// = (elemTop >= 0) && (elemBottom <= window.innerHeight);
    // Partially visible elements return true:
    isVisible = elemTop < window.innerHeight && elemBottom >= 0
    return isVisible
}

// Return result to background script on executeScript to avoid "Could not establish connection"
// noinspection BadExpressionStatementJS
true
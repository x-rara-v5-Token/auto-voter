async function vote(first) {
    if (document.querySelector('.notification') != null) {
        if (document.querySelector('.notification.is-success') != null) {
            chrome.runtime.sendMessage({successfully: true})
            return
        } else if (document.querySelector('.notification.is-warning') != null && (document.querySelector('.notification.is-warning').textContent.includes('Hlasovat můžete až') || document.querySelector('.notification.is-warning').textContent.includes('Hlasovať môžete až'))) {
            //Сайт предоставляет когда следующее голосование но не понятно в каком часовом поясе указано время, также не указывается день (пишет только часы и минуты) что ещё больше осложняет определение времени следующего голосования
            chrome.runtime.sendMessage({later: Date.now() + 7200000})
            return
        } else {
            const request = {}
            request.message = document.querySelector('.notification').textContent.trim()
            if (request.message.toLowerCase().includes('captcha') || request.message.toLowerCase().includes('že nejste robot')) {
                // None
            } else {
                if (request.message.includes('server byl označen jako neaktivní')) {
                    request.ignoreReport = true
                    request.retryCoolDown = 21600000
                } else if (request.message.includes('Přezdívka je v nesprávném formátu')) {
                    request.ignoreReport = true
                }
                chrome.runtime.sendMessage(request)
                return
            }
        }
    }
    if (document.querySelector('body > .container > h1.title')) {
        const request = {}
        request.message = document.querySelector('body > .container > h1.title').textContent
        if (request.message.includes('stránka nebyla nalezena')) {
            request.ignoreReport = true
            request.retryCoolDown = 21600000
        }
        chrome.runtime.sendMessage(request)
        return
    }
    if (document.querySelector('body .container h1.title')?.textContent.includes('Internal Server Error')) {
        const request = {}
        request.message = document.querySelector('body .container h1.title').parentElement.innerText
        request.ignoreReport = true
        chrome.runtime.sendMessage(request)
        return
    }

    if (first) {
        document.querySelector('.columns .column button.button').click()
        return
    }
    let project = await getProject()
    document.querySelector('.modal form input[name="nickname"]').value = project.nick
    document.querySelector('.modal form button[type="submit"]').click()
}